/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int i,n,j,m,f;
    scanf("%d",&n);
    for(i=1 ; i<=n ; i++){
        m=i;
        f=0;
        for(j=2 ; j<m ; j++){
            if(m%j==0){
                f=1;
                break;
            }
        }
        if(f==0)
        printf("%d\n",m);
    }

    return 0;
}
