#include <stdio.h>
#include<math.h>

int main(void) {
	// your code goes he
	int n,a;
	float b,c;
	scanf("%d",&n);
	for(int i=1 ; i<=n ; i++){
	    scanf("%d%f",&a,&b);
	    float c=pow(2 , b);
	    //printf("%f\n",c);
	}
	for(int i=0 ;  i<a ; i++){
	    float c=c-((c*50)/100);
	    printf("%f\n",c);}
	
	return 0;
}

