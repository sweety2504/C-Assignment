/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int D;
    scanf("%d\n",&D);
    int N;
    scanf("%d\n",&N);
    int C;
    scanf("%d\n",&C);
    int E=(D*N*C)/N;
    printf("%d",E);

    return 0;
}
