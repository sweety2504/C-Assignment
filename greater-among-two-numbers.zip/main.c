/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    // printf("Hello World");
    int a, b;
    printf("Enter your first number \t");
    scanf("%d",&a);
    printf("Enter your second number \t");
    scanf("%d",&b);
    if(a>b){
        printf("%d is greater",a);
    }
    else if(a==b){
        printf("Both are equal\n");
    }
    else{
        printf("%d is greater",b);
    }
    
    return 0;
}

