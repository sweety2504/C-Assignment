/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int n,even=0 ,odd=0;
    scanf("%d",&n);
    int a[n];
    for(int i=0 ; i<n ;i++){
        scanf("%d",&a[i]);
    }   
    for(int i=0 ; i<n ;i++){
        if(a[i]%2==0)
        even++;
        else
        odd++;
    }
     printf("Even= %d\n Odd=%d",even ,odd);
    

    return 0;
}
