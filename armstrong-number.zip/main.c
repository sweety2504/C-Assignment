/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include<math.h>

int main()
{
    int sum=0, n,r,s;
     scanf("%d",&n);
    int f=n;
    int k=log10(n)+1;
   
    while(n>0){
        r=n%10;
        n=n/10;
        sum=sum+pow(r , k);
    }
      
    if(sum==f){
        printf("ARMSTRONG"); 
    }
    else{
        printf("NOT ARMSTRONG");
    }
    
    return 0;
}
