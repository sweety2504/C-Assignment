/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*************************************************************************
/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int m,n;
    scanf("%d%d",&m,&n);
    int a[m][n];
    for(int i=0 ; i<m ; i++){
        for(int j=0 ; j<n ; j++){
            scanf("%d",&a[i][j]);
        }
    }
      for(int i=0 ; i<m ; i++){
        for(int j=0 ; j<n ; j++){
            printf("%d\t",a[i][j]);
        }
        printf("\n");
          
      }

       for(int i=0 ; i<n ; i++){
        for(int j=0 ; j<m ; j++){
            
            printf("%d\t",a[j][i]);
        }
        printf("\n");
       }


    return 0;
}

