/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    
    int  n,r,s=0;
    scanf("%d",&n);
    int f=n;
    
   
    while(n>0){
        r=n%10;
        n=n/10;
        s=s*10+r;
        
    }
      
    if(s==f){
        printf("PENULDROME"); 
    }
    else{
        printf("NOT PENULDROME");
    }
    

    return 0;
}
