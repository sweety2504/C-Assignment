/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int W1,W2,W3,W4,W5;
    scanf("%d&%d&%d&%d&%d",&W1,&W2,&W3,&W4,&W5);
       printf("%c%c%c%c%c",W1,W2,W3,W4,W5);
    
    return 0;
}



