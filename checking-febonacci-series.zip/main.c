/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
   int i=1,a=0,b=1,n,c;
   scanf("%d",&n);
    int f = 0;
   if(n==1 || n==0){
       printf("Yes");
   }
   else{
       for(i ; i<=n ; i++ ){
           c=a+b;
           if(c==n){
               f=1;
               break;
           }
           a=b;
           b=c;
       }
       if(f==1){
           printf("Yes");
       }
       else{
           printf("No");
       }
   }

    return 0;
}

