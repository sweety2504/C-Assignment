/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    char a;
    printf("Enter your character \t");
    scanf("%c",&a);
    if(a>=65 && a<=90){
        printf("%c is capital alphabet character",a);
    }
    else if(a>=97 && a<=122){
        printf("%c is small alphabet character",a);
    }
    else{
        printf("It is not the character");
    }

    return 0;
}

