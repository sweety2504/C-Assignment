/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    char a;
    printf("Enter your character \t");
    scanf("%c",&a);
    if(a==65 || a==69 || a==73 || a==79 || a==85){
        printf("%c is capital vowel",a);
    }
    else if(a==97 || a==101 || a==105 || a==117 || a==111){
        printf("%c is smal vowel aphabet",a);
    }
    else{
        printf("%c is consonant",a);
    }

    return 0;
}
