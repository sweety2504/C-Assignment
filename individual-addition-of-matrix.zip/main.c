/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    int m,n,sr ,sc;
    scanf("%d%d",&m,&n);
    int a[m][n];
    for(int i=0 ; i<m ; i++){
        for(int j=0 ; j<n ; j++){
            scanf("%d",&a[i][j]);
        }
    }
    printf("Matrix is : \n");
    for(int i=0 ; i<m ; i++){
        for(int j=0 ; j<n ; j++){
            printf("%d ",a[i][j]);
        }
        printf("\n");
    }
    printf("Sum is :\n");
    for(int i=0 ; i<m ; i++){
        int sr=0 ,sc=0;
        for(int j=0 ; j<n ; j++){
            sr=sr+a[i][j];
            sc=sc+a[j][i];
        }
        printf("Sr = %d\n Sc = %d \n",sr,sc);
}


    return 0;
}
