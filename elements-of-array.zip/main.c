/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
    //printf("Hello World");
    int n;
    scanf("%d",&n);
    int a[n],pos=0 , neg=0 ,zer=0;
    for(int i=0 ; i<n ; i++)
{
    scanf("%d",&a[i]);
}
printf("Array is ; ");
   for(int i=0 ; i<n ; i++)
{
    printf("%d ",a[i]);
}

  for(int i=0 ; i<n ; i++)
{
    if(a[i]>0)
    pos++;
    else if(a[i]<0)
    neg++;
    else 
    zer++;
}
printf("\nPositive elements : %d\n",pos);
printf("Negative elements : %d\n",neg);
printf("Zero elements : %d\n",zer);


    return 0;
}
