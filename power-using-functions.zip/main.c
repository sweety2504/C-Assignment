/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include<math.h>
float power(float p);
int main()
{
    float p;
    scanf("%f",&p);
    power(p);
    printf("%0.5f",power(p));

    return 0;
}
float power(float p){
   float d=pow(p, 2);
    return d;
}
