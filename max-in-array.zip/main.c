/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
  //  printf("Hello World");
  int n,i,max;
  scanf("%d",&n);
  int a[n];
  
  
  for(int i=0 ; i<n ; i++){
      scanf("%d",&a[i]);
      max=a[0];
      
  }
  for(int i=0 ; i<n ; i++){
      if(max<=a[i])
      max=a[i];
  }
  printf("Max is %d",max);

    return 0;
}

