#include<stdio.h>
int main(){
        int m,n,i,j,k,l;
        printf("Enter rows of first matrix : ");
        scanf("%d",&m);
        printf("Enter columns of first matrix : ");
        scanf("%d",&n);
        int a[m][n];
        for(int i=0 ; i<m ; i++){
            for(int j=0 ; j<n ; j++){
                scanf("%d",&a[i][j]);
            }
        }
         for(int i=0 ; i<m ; i++){
            for(int j=0 ; j<n ; j++){
                printf("%d ",a[i][j]);
            }
            printf("\n");
        }
        int o,p;
        printf("Enter rows of second matrix : ");
        scanf("%d",&o);
        printf("Enter columns of second matrix : ");
        scanf("%d",&p);
        int b[o][p];
        for(int k=0 ; k<o ; k++){
            for(int l=0 ; l<p ; l++){
                scanf("%d",&b[k][l]);
            }
        }
        for(int k=0 ; k<o ; k++){
            for(int l=0 ; l<p ; l++){
                printf("%d ",b[k][l]);
            }
            printf("\n");
        }
        int q,r;
        int c[q][r];
         for(int x=0 ; x<q ; x++){
            for(int y=0 ; y<r ; y++){
                c[x][y]==a[i][j]+b[k][l];
            }
        }
         for(int x=0 ; x<q ; x++){
            for(int y=0 ; y<r ; y++){
                printf("%d",c[x][y]);
            }
            printf("\n");
        }



return 0;
}